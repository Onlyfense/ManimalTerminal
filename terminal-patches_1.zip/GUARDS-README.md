# Terminal Crash Fixes — Summary

Two real crashes on Terminal, found from real client/server logs, fixed directly in
`terminal-client` and `terminal-server` (not as separate DLLs — integrated into the
main mod's own patch lists, following the existing per-class-patch conventions in
this repo). A third crash (LotsofLoot dynamic loot generation) was fixed outside this
repo, via LotsofLoot's own `config.jsonc` — see the note at the bottom.

## 1. Client: raid-start `NullReferenceException` (`terminal-client/TerminalCrashGuard.cs`)

Fixes a raid-start crash seen in a client log:

```
Class304.method_3[T] (LegacyParamsStruct request)
Class308.LocalRaidStarted (EFT.LocalRaidSettings settings)
```

- A Harmony **finalizer** on `Class308.LocalRaidStarted` catches any exception raised
  anywhere in its call graph (including from `Class304.method_3` underneath it) and
  swallows it — but **only when `TerminalGate.On` is true**. Every other map rethrows
  the exception unchanged, so this stays fully inert everywhere else.
- `Class304.method_3` is **not** patched directly: it's an open generic method
  (`method_3<T>`), and Harmony cannot patch an open generic method definition. A real
  build attempt confirmed this fails loud (`HarmonyException` / "Specified method is
  not supported") — expected, not a bug — and patching `LocalRaidStarted` alone is
  sufficient.
- Reuses the existing `TerminalGate.PendingLocationId`/`TerminalGate.On` gate (set by
  `TerminalGate.Patch_CaptureLocationId` on `LocalGame.smethod_6`, already armed
  earlier in `Plugin.cs`'s patch list) instead of a second location-capture patch —
  `TerminalGate.On` already falls back to the captured `PendingLocationId` when
  `GameWorld` doesn't exist yet, which matters here: `LocalRaidStarted` fires *during
  matching*, before `GameWorld` exists, so a live-only `GameWorld` check would never
  fire (the "transit-gate-blindness" trap this repo's own notes already warn about).
- Both obfuscated type names (`Class308`) are resolved by reflection
  (`AccessTools.TypeByName`/`AccessTools.Method`) rather than a compile-time
  reference, since they can drift across game/SPT builds. If the name fails to
  resolve, this logs an error at plugin startup instead of silently never patching.
- Wired into `Plugin.cs` via `TerminalCrashGuard.TryPatch(HarmonyInstance)`, in its
  own isolated try/catch alongside `TerminalQuestingBotsOff`/`TerminalLockableDoorsOff`
  — a failure here can't take any other patch down.
- **Confirmed fixed** against a real client log; the identical unpatched crash
  signature was also seen independently in a second user's log.

## 2. Server: vanilla-role bot generation crash (`terminal-server/TerminalApbsGuard.cs`)

Fixes vanilla-role bots (assault, marksman, bossGluhar, followerGluharSecurity)
failing to spawn on Terminal at all:

```
Failed to generate bot #N (assault): Map 'Terminal' not found.
```

- Root cause (found by cloning **Acid's Progressive Bot System (APBS)**'s own
  open-source repo, `acidphantasm/progressivebotsystem-csharp`): unlike LotsofLoot,
  APBS's `Models/ApbsServerConfig.cs` has a `MapRangeWeights` class with a
  string-keyed indexer backed by a **fixed C# `switch` statement** over ~13 hardcoded
  map names, with `_ => throw new KeyNotFoundException($"Map '{key}' not found.")`
  for anything else — read by `CustomBotWeaponGenerator.cs` as
  `MapRangeWeighting[RaidInformation.RaidLocation]` to weight long/short-range weapon
  selection per map. Unlike LotsofLoot, there is **no config file** that can add
  Terminal support here — the map list is compiled into the DLL, so a code-level guard
  is the only fix available.
- Fix: a Harmony **finalizer** on APBS's `MapRangeWeights` indexer getter catches the
  `KeyNotFoundException` and, only for key `"Terminal"`, supplies a default
  `LongShortRange` (20% long-range / 80% short-range, matching
  Interchange/TarkovStreets) instead of letting the exception propagate. Every other
  map's lookup — known or unknown — is untouched.
- The APBS type/method is resolved via reflection
  (`AccessTools.TypeByName`/`AccessTools.Method`), so this has no compile-time
  dependency on APBS and stays inert (logs a warning, does nothing) if APBS isn't
  installed or has changed its internals.
- Custom bot roles (blackDivAssault, ruaf*, civilian) are unaffected — the same server
  log showed they generate fine on Terminal already; only vanilla roles go through
  this APBS code path.
- Registered as its own `[Injectable(TypePriority = OnLoadOrder.PostDBModLoader +
  90004)]` `IOnLoad` class in the same `terminal-server` assembly.
- **Confirmed working** via a follow-up server log: `[TerminalApbsGuard]` logged the
  substitution repeatedly, and bot generation went from `0 bot(s) ... EMPTY RESPONSE
  (the storm)` to `77 bot(s) [assaultx45, marksmanx32] for a request of 64`.

## Note: LotsofLoot dynamic loot crash (fixed outside this repo)

A third crash was also found and fixed during this pass, but it doesn't live in this
repo: a server-side 500 on `/client/match/local/start`
(`LotsofLoot.Generators.LotsofLootLocationLootGenerator.GenerateDynamicLoot` throwing
`The given key 'terminal' was not present in the dictionary.`). Root cause (found by
disassembling LotsofLoot's own IL directly — no .NET SDK was available, so
`dnfile`/`dncil` in Python were used to read the PE/CIL metadata and pinpoint the
exact crashing line): the third-party mod **LotsofLoot** keeps its own per-map loot
config (`Limits`, `LooseLootMultiplier`, `StaticLootMultiplier`) keyed by location
name in its own `config.jsonc`, with no entry for `"terminal"`. Fixed by adding a
`"terminal"` entry directly to LotsofLoot's `config.jsonc` (sized off
`looseLoot.json`'s spawnpoint count to match similarly-sized maps like Bigmap/Woods)
— no code change needed here, and Terminal gets proper LotsofLoot-generated dynamic
loot instead of an empty fallback. Confirmed working in a follow-up log.

## Build notes

`terminal-client` and `terminal-server` reference the SPT client (`$(SPTPath)\...`) or
the `SPTarkov.Server.Core` NuGet package plus `0Harmony.dll` from a real SPT
installation, neither of which is available outside a Windows dev box, so none of
this could be compiled where it was written (no .NET SDK either). Both fixes here
were written to strictly match existing, working patterns already in this repo
(`TerminalGate.cs`'s reflection/finalizer style, `TerminalQuestingBotsOff`'s
`TryPatch(Harmony)` convention, `TerminalMod`/`TerminalMagTuner`'s `[Injectable]`
`IOnLoad` pattern), and root causes were confirmed from real client/server logs, or by
reading the relevant third-party mod's own open-source code (APBS) — not guesswork.
Both have since been confirmed fixed against real test logs, as has the LotsofLoot
`config.jsonc` fix noted above.
